% assign_gradentDescent.m 
%
% linear regression, using gradient descent
% objective function to minimize = sum-square error -> "least squares"
% finds line, y = w0 + w1*x, to best fit a set of measured x,y data pts


clear all;   close all;     
fprintf(1,'\n\n\n\n');

% this is our simulated data:
xData = rand(1,10)-0.5;    % some random x-values
yData = 0.2 + 2.0*xData;   % corresponding y-values
yData = yData + 0.2*(randn(1,10)-0.5);  % with some added noise
nDataPts = length(xData);   

% learning rate
eta = input('learning rate:   '); %0.1 and 50 
if isempty(eta) error('please specify a learning rate'); end

num_iterations = input('number of iterations, before stopping:   ');
if isempty(num_iterations) ;  num_iterations = 50;  end

% initialize weights:  Gaussian rn's, mean=0, var=1
w1 = randn(1);         
w0 = randn(1); 
% in Task 2, I am asking you to graph "predicted and measured values 
%(different line types) vs. time" - there is one measurement at each "time" 
%point (since here we assume a static receptive field, with no time dynamics) - 
%so here, there are nMeasTest measurements (time points) for the Test dataset.

% initialize data plot (adjust these offsets as you like, to fit your screen)
xOff = 60;  % from left of screen
if isunix
    yOff=1000;    % from bottom of screen
elseif ispc
    yOff=60;      % from top of screen
else
    error('unrecognized operating system');
end
xSize=300;  ySize=1*xSize;
figHanMain = figure('position',[xOff yOff xSize ySize]);

plot(xData,yData,'ro');  xlabel('x');  ylabel('y');  hold on

% plot line implied by initial-guess weights
xMax = 1.3*max(abs(xData));     yMax = 1.3*max(abs(yData));
xx=[-1 xMax];   
yy = w0 + w1*xx;
axis([-1 xMax -1 yMax])
pltHandle = plot(xx,yy);   grid on;   drawnow;   % (note, NOT doing "hold off" ...)


% loop over iterations
lossMatrix = zeros(1,num_iterations ); %I make some matrix to store all the values 
dw1Matrix = zeros(1,num_iterations);
dw0Matrix = zeros(1,num_iterations);
for iter = 1:num_iterations
   % initialize dw's and E
   dw1    = 0;
   dw0    = 0;
   E_loss = 0;
   % loop over training set
   
   for iDataPt=1:nDataPts 
        yCalc = w0 + w1*xData(iDataPt); % predicted yValue
        
        dw1 = dw1 + (yCalc - yData(iDataPt))*xData(iDataPt);  % 
        
        dw0 = dw0 + yCalc - yData(iDataPt); 
        
        E = yData(iDataPt) - yCalc;     % error in our prediction
                
        % accumulate error
        E_loss = E_loss + E^2;  % loss function = error-squared
   end
   % update weights, and record for history
   w1 = w1 - eta*dw1;  
   w0 = w0 - eta*dw0; 
   
   lossMatrix(iter) = E_loss;
   dw1Matrix(iter) = w1;
   dw0Matrix(iter) = w0;
   
   % update display of regression line
   yy = w0 + w1*xx;
   set(pltHandle,'YData',yy);   % (note, "pltHandle" from above)
   drawnow;
   
end
%error (loss) vs. itera;ons (done)
%parameter values (w0, w1) vs. itera;ons
%annotaion, on the Figure: learning rate
%(Discover yourself, what is a �good� learning rate).
formatSpec = 'current input learning rate: %f, with final loss around: %f , \n Recommand learning rate around 0.1, with final loss around 0.4 ';
str = sprintf(formatSpec,eta,E_loss);
dim = [.15 .5 .3 .4];
figure(2) 
subplot(2,1,1);
hold on; 
title('plot 2 error (loss) vs. iteraions'); 
xlabel('iterations');
ylabel('loss - square error');
annotation('textbox',dim,'String',str,'FitBoxToText','on');
plot(1:num_iterations,lossMatrix); %x = iterations %y = loss square error 
hold off; 

subplot(2,1,2);
hold on; 
title('plot 3 parameter values (w0) vs. iterations'); 
xlabel('iterations');
ylabel('w(0)'); 
plot(1:num_iterations,dw0Matrix);
plot(1:num_iterations,dw1Matrix);
legend('w(0)','w(1)');
hold off; 

figure(3); 
hold on; 
grid on;  
title('Final figure'); 
pltHandle = plot(xx,yy);
plot(xData,yData,'ro');
axis([-1 xMax -1 yMax]);
xlabel('x');  ylabel('y');


fprintf(1,'\nfinal loss = %f\n', E_loss);


