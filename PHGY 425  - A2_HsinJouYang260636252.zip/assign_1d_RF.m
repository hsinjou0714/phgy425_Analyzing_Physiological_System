% assign_1d_RF.m 
%
% simple regression estimation of 1-d (spatial) receptive field
% Blue line is the 1  D receptive field 
% blue line : inhibite -> excite -> inhibit -> excite 
% the y axis are the weights 
%make image: generate te predicted output against the ageravge output, it
%should follow a straight line, and measure R^2, demo is VAF = 77.8. (the percentage 
%of fitting varince ) here you can even do better than this


clear all;  close all;  fprintf(1,'\n\n\n\n\n\n');

nRFpts = 32;    % number of points in receptive field (== number of parameters to be estimated)
nMeasTrain = 64;     % number of measurements to use for receptive field Training data
nMeasTest = 32;      % number of measurements for "Test" dataset

eta = input('learning rate:   '); 
if isempty(eta) error('please start again, and give learning rate'); end

num_iterations = input('number of iterations:   '); 
if isempty(num_iterations) error('please start again, and this time answer all the questions !'); end
    
figHanMain = figure('position',[60 1000 400 300]);
    
% define a model receptive field (Gabor function), and plot it
xPtsK = 1:1:nRFpts;
mu = nRFpts/2;   lambda = nRFpts/5;   sig = lambda*0.5;
env = exp(-(xPtsK-mu).^2/(2*sig^2));  % Gaussian envelope
receptiveField = env.*sin(2*pi*xPtsK/lambda);
figure(figHanMain); 

% create an input signal (stimulus):   white noise, range from -1 to +1
stimTrain = (rand(nRFpts,nMeasTrain) - 0.5);   % stimuli for Training
stimTest  = (rand(nRFpts,nMeasTest) - 0.5);  % stimuli for Test
% simulate response of the model system (receptive field) to input signal (with some added noise) 
respTrain = receptiveField*stimTrain + 0.15*randn(1,nMeasTrain);  % response to Training stimuli
respTest= receptiveField*stimTest + 0.15*randn(1,nMeasTest);  % response to Test stimuli

% stim   = nRFpts x nMeas
% resp   = 1 x nMeas           % note stim and resp are ~ zero-mean 
% w      = 1 x nRFpts

w = randn(1,nRFpts);   % random initial weights (receptive field estimate)

figure(figHanMain);  % bring figure to foreground

%figure error 
lossMatrix =  zeros(1,num_iterations );

for iteration = 1:num_iterations    % loop over iterations
   respCalc = w*stimTrain;             % predicted response

   % gradient descent
   dw = (respCalc - respTrain)*stimTrain';  % gradient 
   w = w - eta*dw;   % learning rule:  update weights   
    
   RF_est = w;

   % redraw plot of receptive field estimate 
   plot(xPtsK,receptiveField,'b-',xPtsK,RF_est,'ro');   grid;
   % set axis limits, to keep things stable:
   xMin = min(xPtsK);    xMax = max(xPtsK);
   yMin = 1.5*min(receptiveField);  yMax = 1.5*max(receptiveField);
   axis ([xMin xMax  yMin yMax]);
   legend('actual receptive field','estimated receptive field');
   drawnow  
 
   %caculation for error 
   
    E_loss = 0; 
    predRespTest = RF_est*stimTest;
    % accumulate error
    E_loss = sum((respTest - predRespTest).^2);  % loss function = error-squared
    lossMatrix(iteration) = E_loss ;%code
end
 
   % assess how well this estimated RF can predict the Test dataset:
    predRespTest = RF_est*stimTest;
    % VAF (variance accounted for), for respTestCalc vs respTest
    vaf.R_matrix = corrcoef(respTest,predRespTest);  % 2 x 2 matrix, ones on diagonal
    vaf.offDiag = vaf.R_matrix(1,2);
    vaf.R_sq = vaf.offDiag^2;
    fprintf('VAF = %3.1f percent\n', vaf.R_sq*100);
   
strX = sprintf('VAF = %3.1f percent', vaf.R_sq*100);
han.txt = text(20,-.8,strX);   % plot the text, in lower right
set(han.txt,'FontSize',12);
set(han.txt,'FontWeight','bold');
set(han.txt,'BackgroundColor','white');
set(han.txt,'EdgeColor','black');

formatSpec = 'current input learning rate: %f, with VAF: %f , \n Recommand learning rate around 0.1 with around 10 iteration';
str = sprintf(formatSpec,eta,vaf.R_sq*100);
dim = [.15 .5 .3 .4];

% Figure, showing error (loss) vs. iteraions
figure(2);
title('Error vs. iterations '); 
ylabel('loss - square error');
xlabel('Iteration number');
annotation('textbox',dim,'String',str,'FitBoxToText','on');
hold on; 
plot(1:num_iterations,lossMatrix); %x = iterations %y = loss square error 
hold off; 


%Figure, with 2 subplots:
    %scatter plot of predicted vs measured values
    %predicted and measured values (different line types) vs. time
figure(3);
subplot(2,1,1);
grid on; 
title('predicted vs measured values'); 
xlabel('Measured Values');
ylabel('Predicted Values ');
hold on;
scatter(respTest, predRespTest); 
hold off;

subplot(2,1,2);
hold on;
title('Predicted and Measured Measurement vs Time '); 
xlabel('Time point');
ylabel('Predicted and Measured Values');
plot(1:nMeasTest,respTest); %The measured vs Time 
plot(1:nMeasTest, predRespTest); %The predicted vs Time 
legend('Measured Values','Predicted Values');
hold off; 

figure(4);
hold on;
grid on; 
title('Final Figure'); 
plot(xPtsK,receptiveField,'b-',xPtsK,RF_est,'ro');  
axis ([xMin xMax  yMin yMax]);
legend('actual receptive field','estimated receptive field');
strX = sprintf('VAF = %3.1f percent', vaf.R_sq*100);
han.txt = text(20,-.8,strX);   % plot the text, in lower right
set(han.txt,'FontSize',12);
set(han.txt,'FontWeight','bold');
set(han.txt,'BackgroundColor','white');
set(han.txt,'EdgeColor','black');
hold off;




%Figure, showing actual (model) recep;ve field profile, and
%the �learned� (es;mated) recepive field,
%using different line and/or symbol types
%and annota;on showing VAF (variance accounted for)

