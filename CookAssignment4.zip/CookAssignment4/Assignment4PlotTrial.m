clear all

load MTNeuralData1

figure(1);
clf;

subplot(4,1,1);
stem(trial(1).motionDirection)
xlim([0 500]);
ylim([-1.4 1.4]);
ylabel('Motion Direction');
set(gca,'YTick', [-1 1], 'YTickLabel', {'Null' ; 'Pref'});
xlabel('Time (ms)');
title('Motion Stimulus');

subplot(4,1,2);
stem(trial(1).spikes)
xlim([0 500]);
ylim([-.2 1.2]);
ylabel('Spikes');
set(gca,'YTick', [0 1]);
xlabel('Time (ms)');
title('Recorded Action Potentials');

subplot(4,1,3);
stem(trial(1).binTimeMS, trial(1).binnedMotionDirection)
xlim([0 500]);
ylim([-1.4 1.4]);
ylabel('Binned Motion Direction');
set(gca,'YTick', [-1 1], 'YTickLabel', {'Null' ; 'Pref'});
xlabel('Time (ms)');
title('Binned Motion Stimulus');

subplot(4,1,4);
stem(trial(1).binTimeMS, trial(1).binnedNumOfSpikes)
xlim([0 500]);
%ylim([-.2 1.2]);
ylabel('Number of Spikes');
xlabel('Time (ms)');
title('Binned Action Potentials');