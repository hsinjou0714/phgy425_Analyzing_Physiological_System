
x = 1 : 10;
n = 10*randn(1,length(x)); % noise term

y = .5*x.^2 + .5*x + 4 + n;

figure(1);
clf;

subplot(1,2,1);
hold on;
plot(x,y,'o', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
xlabel('x'); 
ylabel('y');

p = polyfit(x,y,2);

yFit = polyval(p,x);

plot(x,yFit,'-s', 'MarkerSize', 10);


subplot(1,2,2);
hold on;
plot(yFit, y, 'o', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
mn = min([yFit, y]);
mx = max([yFit, y]);
plot([mn mx], [mn mx], 'k--');
R = corr(yFit', y');
title(['Rsq = ' num2str(R^2,2)]);
xlabel('yHat'); 
ylabel('y');