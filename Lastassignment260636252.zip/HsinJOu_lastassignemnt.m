clear all; close all;

load AssigDat.asc;      
                       
%1)	size = 10000 x 5, 5 columns, length : 10000


%% Extract columns
t  = AssigDat(:,1); %first column with mmsec time 
y1 = AssigDat(:,2); %secind column and so on(respons to current)
y2 = AssigDat(:,3);
y3 = AssigDat(:,4);
y4 = AssigDat(:,5);



%% plot graph
figure();
    plot(t,y1,t,y2,t,y3,t,y4);
    title('Patch Current vs. Time for AMPA Channels');
    xlabel('Time (ms)');
    ylabel('Patch Current (pA)');
    legend('Trace 1','Trace 2','Trace 3','Trace 4');
    grid on;
 
%Question 1: the spped of onset is very similar in each case, they are all
%around 0.4ms

%Question 2 : no, the mean of steady state did not coincide. the data is
%very different with. data 1 the smallest, data 2 the medium, data 3 follow
%and data 4 the largest. 

% question 3: the variation looks very similar berween each other. The
% variation in data 3 lookest a bit larger than all the other, abd the data
% 3 and 4 looks very similar. with the data in set 1 looks the smallest. 


%% quantitative evalution 
% Extrat steady-state sagments
% the steady state seemes to occur after 1ms 
for i = 1:size(t)
    if  t(i)>1
        t_1ms = i;
        break;
    end     
end
%starting time point to the end point 
z1 = y1(t_1ms: end);
z2 = y2(t_1ms: end);
z3 = y3(t_1ms: end);
z4 = y4(t_1ms: end);



%% Plot Frequency Histograms

figure();
    subplot(2,2,1);
        histogram(z1,50);
        xlabel('Current (pA)');
        ylabel('Frequency the Current Appears');
        title('Trace 1 Current Distribution with 50 bins');
	subplot(2,2,2);
        histogram(z1,100);
        xlabel('Current (pA)');
        ylabel('Frequency the Current Appears');
        title('Trace 1 Current Distribution with 100 bins');
    subplot(2,2,3);
        histogram(z1,500);
        xlabel('Current (pA)');
        ylabel('Frequency the Current Appears');
        title('Trace 1 Current Distribution with 500 bins');
    subplot(2,2,4);
        histogram(z1,1000);
        xlabel('Current (pA)');
        ylabel('Frequency the Current Appears');
        title('Trace 1 Current Distribution with 1000 bins');
% 50 bin, 100 bin, 500 bin, 1000 bins are tried in the subplot of the
% figure. As the bin increasees, the picture gets finner and finner and get
% more detailed.
        
% 100 bins are used in the histograms for trace 1 to trace 4.
figure();
    subplot(2,2,1);
        histogram(z1,1000);
        xlabel('Current (pA)');
        ylabel('Frequency the Current');
        title('Trace 1 Current');
    subplot(2,2,2);
        histogram(z2,1000);
        xlabel('Current (pA)');
        ylabel('Frequency the Current');
        title('Trace 2 Current');
    subplot(2,2,3);
        histogram(z3,1000);
        xlabel('Current (pA)');
        ylabel('Frequency the Current');
        title('Trace 3 Current');
    subplot(2,2,4);
        histogram(z4,1000);
        xlabel('Current (pA)');
        ylabel('Frequency the Current');
        title('Trace 4 Current');



%% Mean and Variance

% caculation of mean in z1, z2, z3, z4
mz1 = mean(z1);
mz2 = mean(z2);
mz3 = mean(z3);
mz4 = mean(z4);

% add a value 0 in the very begging of each array 
mmz(1) = 0;
mmz(2) = mz1;
mmz(3) = mz2;
mmz(4) = mz3;
mmz(5) = mz4;

% Variance of z1, z2, z3, z4
vz1 = var(z1);
vz2 = var(z2);
vz3 = var(z3);
vz4 = var(z4);

% add a value 0 in the very begging of each array 
vvz(1) = 0;
vvz(2) = vz1;
vvz(3) = vz2;
vvz(4) = vz3;
vvz(5) = vz4;
% mean-variance plot
figure();
    plot(mmz,vvz,'k.','MarkerSize',20);
    grid on;
    xlabel('Current Mean Value (pA)');
    ylabel('Current Variance (pA)');
    title('The Current Variance vs. Mean for Each Trace');



%% Fitting

% equation : current variance  = (single channel current)*(mean) -
% (mean).^2/number 
% want SCC
% When mmz is very small, SCC = vvz./(mean), which is the slope between
% mean and var
% first 3 elements of mmz & vvz
emmz = mmz(1:3);
evvz = vvz(1:3);
%obtain the first 3 numbers 
a = polyfit(emmz,evvz,1);% the poly input 1 as first order 
SCC1 = a(1); % first is the slope so it is the correct ourput 

% Signle chanel conductance, r = SCC/(V(membrane potential)-Er (reversal
% potential)), assume V-Er=100mv
gamma = SCC1/0.1;


% Estimated by eye, here we think that the max is at 280pA
N1 = 2*280/SCC1;


% second polynomial order 
param = polyfit(mmz,vvz,2);

SCC2 = param(2);
N2 = -1/param(1);


%% Compare Fitting Line with Experimental Data

% Generate the fitting line
xx = [1:1:450];
yy = param(1).*(xx.^2) + param(2).*xx;

% Plot the figure
figure();
    plot(xx,yy,'b-');
    hold on;
    plot(mmz,vvz,'k.','MarkerSize',20);
    grid on;
    set(gca,'XLim',[0 400]) ;
    xlabel('Current Mean Value (pA)');
    ylabel('Current Variance (pA)');
    title('The Current Variance vs. Mean');
    legend('Fitting Curve', 'Experimental Data');
    hold off;


%% Questions

% a) question 1 
yy_SCCx2 = param(1).*(xx.^2) + param(2)*2.*xx;

% b) channel twice as large 
yy_Nx2 = param(1)/2.*(xx.^2) + param(2).*xx;

% Plot the new curves;
figure();
    hold on;
    plot(xx,yy,'k-');
    plot(xx,yy_SCCx2,'b-');
    plot(xx,yy_Nx2,'g-');
    grid on;
    xlabel('Current Mean Value (pA)');
    ylabel('Current Variance (pA)');
    title('The Chanel Current Variance vs. Mean with Different SCC or N');
    legend('Original fitting curve', 'SCC twice as large', 'N twic as large');












%

