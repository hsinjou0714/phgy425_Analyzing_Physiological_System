% assign_1d_RF_overfitting.m 
%
% demonstrate overfitting, and concept of early stopping, 
%   for simple regression estimation of 1-d (spatial) receptive field

clear all;  close all;  fprintf(1,'\n\n\n\n\n\n');

rng('default');  % "standard" random number seed -> reproducible simulations 

nRFpts = 32;    % number of points in receptive field (== number of parameters to be estimated)
nMeasTrain = 40;     % number of measurements to use for receptive field estimation
nMeasValid = 40;     % number of measurements for "Valid" dataset

commandwindow;
eta = 0.2; 
if isempty(eta)  eta=0.2;  end
num_iterations = 100;  
if isempty(num_iterations) ;  num_iterations = 50;  end

figHanMain = figure('position',[60 1000 400 300]);

%%% $$ ->  set up new figure window:    % YOUR CODE HERE ...

% define a model receptive field (Gabor function), and plot it
xPtsK = 1:1:nRFpts;
mu = nRFpts/2;   lambda = nRFpts/5;   sig = lambda*0.5;
env = exp(-(xPtsK-mu).^2/(2*sig^2));  % Gaussian envelope
receptiveField = env.*sin(2*pi*xPtsK/lambda);
figure(figHanMain); 

% create an input signal (stimulus):   white noise, range from -1 to +1
stimTrain = (rand(nRFpts,nMeasTrain) - 0.5);   % stimuli for estimation
stimValid= (rand(nRFpts,nMeasValid) - 0.5);  % stimuli for prediction
% simulate response of the model system (receptive field) to input signal (with some added noise) 
respTrain = receptiveField*stimTrain + 0.15*randn(1,nMeasTrain);  % response to estimation stimuli
respValid= receptiveField*stimValid + 0.15*randn(1,nMeasValid);  % response to prediction stimuli
% stim   = nRFpts x nMeas
% resp   = 1 x nMeas           % note stim and resp are ~ zero-mean 
% w      = 1 x nRFpts

% allocate arrays, to store errors for Training and Validation datasets
errTrain = zeros(1,num_iterations);
errValid = zeros(1,num_iterations);

w = 0.2*randn(1,nRFpts);   % random initial weights (receptive field estimate)

for iteration = 1:num_iterations    % loop over iterations
   respCalc = w*stimTrain;             % predicted response

   % gradient descent
   dw = (respCalc - respTrain)*stimTrain';  % gradient 
   w = w - eta*dw;   % learning rule:  update weights   
    
   RF_est = w;

   figure(figHanMain);  % bring figure to foreground
   % redraw plot of receptive field estimate 
   plot(xPtsK,receptiveField,'b-',xPtsK,RF_est,'r.',xPtsK,RF_est,'r-' );   grid;
   % set axis limits, to keep things stable:
   xMin = min(xPtsK);    xMax = max(xPtsK);
   yMin = 1.5*min(receptiveField);  yMax = 1.5*max(receptiveField);
   axis ([xMin xMax  yMin yMax]);
   legend('actual receptive field','estimated receptive field');
   drawnow
   
   % assess how well this estimated RF can predict both the Training and the Validation data
   predRespTrain = RF_est*stimTrain; 
   predRespValid = RF_est*stimValid;
   
   % record error, for each: 
   errTrain(iteration) =   % YOUR CODE HERE ...
   errValid(iteration) =   % YOUR CODE HERE ...
   
   %%%  record VAF for validation data, at this iteration:    
   vafValid(iteration) =  % YOUR CODE HERE ...
end


%%% $$ -> calculate VAF:   YOUR CODE HERE ...


%%% $$ -> YOUR CODE HERE:
%           in the new figure window,
%               plot training error and validation error, vs iteration number
%                   with legend for the Training and Validation errors
%       ( as you saw, in the class demo )
%           - indiate best place to stop
%           - annotaton, to show VAF at this iteration

